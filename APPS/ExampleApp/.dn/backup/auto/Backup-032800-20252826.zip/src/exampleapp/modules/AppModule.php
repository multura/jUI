<?php
namespace exampleapp\modules;

use std, gui, framework, exampleapp;


class AppModule extends AbstractModule
{

}