<?php
namespace exampleapp\modules;

use std, gui, framework, exampleapp;


class MainModule extends AbstractModule
{

}