<?php
namespace exampleapp\forms;

use std, gui, framework, exampleapp;


class MainForm extends AbstractForm
{

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        
    }

}
