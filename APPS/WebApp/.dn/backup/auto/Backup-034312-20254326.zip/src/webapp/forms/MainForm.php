<?php
namespace webapp\forms;

use std, gui, framework, webapp;


class MainForm extends AbstractForm
{

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        
    }

}
