<?php
namespace webapp\modules;

use std, gui, framework, webapp;


class AppModule extends AbstractModule
{

}