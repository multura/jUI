<?php
namespace webapp\modules;

use std, gui, framework, webapp;


class MainModule extends AbstractModule
{

}