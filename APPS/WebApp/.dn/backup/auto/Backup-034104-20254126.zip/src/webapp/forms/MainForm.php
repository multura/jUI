<?php
namespace webapp\forms;

use std, gui, framework, webapp;


class MainForm extends AbstractForm
{

}